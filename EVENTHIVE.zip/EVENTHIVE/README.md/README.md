# EventEase

EventEase is a responsive event booking website built with HTML, CSS, JavaScript, and Bootstrap. It allows users to book tickets for movies, concerts, sports, comedy shows, and more.

## Features
- User authentication (signup/login)
- Event browsing and booking
- Payment gateway simulation
- Responsive design with Bootstrap
- Smooth animations and modern UI

## Setup
1. Clone the repository.
2. Open `pages/index.html` in a browser or use a local server (e.g., `live-server`).
3. Ensure internet access for Bootstrap CDN.

## Color Palette
- Primary: #46414E (Dark Gray)
- Secondary: #970C3F (Deep Pink)
- Accent & Background: #FFFFFF (White)