$(document).ready(function() {
  // Sign Up Functionality
  $('#signupForm').submit(function(e) {
      e.preventDefault();
      const email = $('#signupEmail').val();
      const password = $('#signupPassword').val();
      const name = $('#signupName').val();
      
      // Validate inputs
      if (!validateEmail(email)) {
          showAlert('Please enter a valid email address', 'danger');
          return;
      }
      
      if (password.length < 8) {
          showAlert('Password must be at least 8 characters', 'danger');
          return;
      }
      
      // Check if user already exists
      if (localStorage.getItem(email)) {
          showAlert('An account with this email already exists', 'danger');
          return;
      }
      
      // Store user data in localStorage (for demo purposes)
      const user = {
          email: email,
          password: password,
          name: name,
          bookings: []
      };
      
      localStorage.setItem('currentUser', JSON.stringify(user));
      localStorage.setItem(email, JSON.stringify(user));
      
      showAlert('Account created successfully! Redirecting to home page...', 'success');
      setTimeout(() => {
          window.location.href = '../index.html';
      }, 2000);
  });
  
  // Login Functionality
  $('#loginForm').submit(function(e) {
      e.preventDefault();
      const email = $('#loginEmail').val();
      const password = $('#loginPassword').val();
      
      const user = JSON.parse(localStorage.getItem(email));
      
      if (user && user.password === password) {
          localStorage.setItem('currentUser', JSON.stringify(user));
          showAlert('Login successful! Redirecting...', 'success');
          setTimeout(() => {
              window.location.href = '../index.html';
          }, 1500);
      } else {
          showAlert('Invalid email or password', 'danger');
      }
  });
  
  // Helper functions
  function validateEmail(email) {
      const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return re.test(email);
  }
  
  function showAlert(message, type) {
      const alert = $(`<div class="alert alert-${type} alert-dismissible fade show" role="alert">
          ${message}
          <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>`);
      
      $('#authAlerts').empty().append(alert);
  }
  
  // Check if user is logged in and update UI
  function checkAuthState() {
      const user = JSON.parse(localStorage.getItem('currentUser'));
      if (user) {
          $('.auth-buttons').html(`
              <div class="dropdown">
                  <button class="btn btn-outline-light dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown">
                      <i class="fas fa-user me-1"></i> ${user.name}
                  </button>
                  <ul class="dropdown-menu">
                      <li><a class="dropdown-item" href="../pages/bookings.html">My Bookings</a></li>
                      <li><hr class="dropdown-divider"></li>
                      <li><a class="dropdown-item" href="#" id="logoutBtn">Logout</a></li>
                  </ul>
              </div>
          `);
          
          $('#logoutBtn').click(function(e) {
              e.preventDefault();
              localStorage.removeItem('currentUser');
              window.location.href = '../index.html';
          });
      }
  }
  
  // Initialize auth state check
  checkAuthState();
});